const Header = () => {
  // TODO #10
  // Crea el JSX corresponent al component Header tenint en compte la semàntica de les etiquetes.
  return (
    <header>
      <h1>Instapicsum</h1>
    </header>
  )
  
}

export default Header
